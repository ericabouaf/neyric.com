/*

    dictionnary.c
    Microforth interpreter

    By Eric Abouaf
    neyric@via.ecp.fr
    June 10, 2005

    This file contains the main dictionnary variables
    ans allocate space for the dictionnary.

    The structure of the dictionnary is the following :

                            last_def
                            |
    ---------------------------------- - -
    | Word1 | Word2 | Word3 | Word 4 | ...
    ---------------------------------- - -
    ^               ^                ^
    dp0             fence            dp

    dp0:        start of the dictionnary
    dp:         first cell available at the end of the dictionnary
    fence:      before fence, the interpreter cannot FORGET
    last_def:   Adress of the last definition

    The structure of a word within the dictionnary is the following:

PFA -------------------------
    | Flags |  name_length  |
    -------------------------
    |       Word Name       |
    -------------------------
    |     Previous Word     |   Pointer to the PFA of the previous word
CFA -------------------------
    |       Code Word       |        EXEC_WORD | COLON_WORD
    -------------------------
    |                       |
    |          Data         |
    |                       |
    -------------------------
*/

#include "dictionnary.h"
#include "core.h"

#define     DICO_SIZE       8000


#define     EXEC_WORD       0
#define     COLON_WORD      1

#define     IMMEDIATE_WORD  32

void * dp0;
void * dp;
void * fence;
void * last_def;

// init_dictionnary()
//
// Function:    Allocates memory for the dictionnary
//              and initiate dictionnary pointers
// Arguments:   None
// Returns:     Nothing
//
void init_dictionnary()
{
    // Allocates memory 
    // +1 => no definition starting by 0
    dp0 = (void *) malloc(DICO_SIZE)+1;

    // Set dico pointers
    dp = dp0;
    fence = dp0;

    // First definition has no previous word
    last_def = 0;

    core_definitions();
}

// core_definitions()
//
// Function:    Creates entries in the dictionnary
// Arguments:   None
// Returns:     Nothing
//
void core_definitions()
{
     add_core_word(".", &dot, 0);
     add_core_word(".s", &dots, 0);
     add_core_word("+", &plus, 0);
     add_core_word("words", &words, 0);
     add_core_word("quit", &quit, 0);
     add_core_word(":", &colon, IMMEDIATE_WORD);
     add_core_word(";", &semicolon, IMMEDIATE_WORD);
     add_core_word("dp@", &dpat, 0);
     add_core_word("dup", &dup, 0);
     add_core_word("*", &mult, 0);
}

// free_dictionnary()
//
// Function:    Frees the memory allocated for the dictionnary
// Arguments:   None
// Returns:     Nothing
//
void free_dictionnary()
{
    // frees the memory of the dictionnary
    free(dp0);
}


// add_core_word()
//
// Function:    Create a new entry in the dictionnary
// Arguments:   
//      - word:     string of the word
//      - function: adress of the C function 
//      - flags:    IMMEDIATE or NULL
// Returns:     Nothing
//
void add_core_word(const char *word, void *function, unsigned char flags)
{
    void * temp_dp = dp;

    unsigned char temp;

    // Get the size of the word (between 1..31)
    unsigned char length = (unsigned char) strlen(word);
    unsigned char length_flags = length | flags;

    // Write the first byte (flags+length)
    memcpy(dp, &length_flags, sizeof(unsigned char) );
    dp += sizeof(unsigned char); 
    
    // Write the name of the word
    // adds the zero at the end for strcmp
    memcpy(dp, (void *) word, length+1);
    dp += sizeof(char)*(length+1);
    
    // Write the pfa of the previous word
    memcpy(dp, &last_def, sizeof(void *) );
    dp += sizeof(void *);
    
    // Write the Code Word, which is in this case only EXEC_WORD
    temp = EXEC_WORD;
    memcpy(dp, &temp, sizeof(unsigned char) );
    dp += sizeof(unsigned char);

    // Write the PFA (Address of the execution function)
    memcpy(dp, &function, sizeof(void *) );
    dp += sizeof(void *);
    
    // Set the last_def variable
    last_def = temp_dp;
}

