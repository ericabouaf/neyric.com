/*
    main.c
    Microforth interpreter

    By Eric Abouaf
    neyric@via.ecp.fr
    June 10, 2005

    This file contains the main initialisations and the infinite loop.

*/

#include <stdio.h>          // printf
#include <stdlib.h>         // exit

#include "main.h"

#include "dictionnary.h"
#include "stacks.h"
#include "input_buffer.h"
#include "parser.h"


// init()
//
// Function:    Prints infos
//              Allocates space for stacks and dictionnary
// Arguments:   None
// Return:      Nothing
//
void init()
{
    // Prints infos
    printf("Microforth interpreter\n");
    printf("By Eric Abouaf\n");
    printf("neyric@via.ecp.fr\n");
    printf("June, 2005\n\n");

    // Allocates space for input_buffer, dictionnary, stacks
    init_inputbuffer();
    init_dictionnary();
    init_stacks();
}

// free_mem()
//
// Function:    Frees the allocated memory
// Arguments:   None
// Return:      Nothing
//
void free_mem()
{
    // Free allocated memory for dictionnary, input_buffer, stacks
    free_inputbuffer();
    free_dictionnary();
    free_stacks();
}


// main()
//
// Function:    Entry point of the application
// Parameters:  None 
// Return:      0 (always)
//
int main(void)
{
   // Allocates memory
   init();
  
   // Infinite loop
   for( ; ; )
   {
        // Print prompt 
        printf(" OK\n");

        // Fills input_buffer
        fill_inputbuffer();

        // Call the parser
        parser();
   }

   // Never called, for compilation
   return 0;
}

