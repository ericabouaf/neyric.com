
// definitions for stacks.c

void init_stacks();
void free_stacks();


