/*
    parser.c
    Microforth interpreter

    By Eric Abouaf
    neyric@via.ecp.fr
    June 10, 2005

    This file parse the input buffer and execute the following:

    I) Parse next word in input buffer
    II) Lookup the word in the dictionnary
        1. If found
            i)if compiling:
                - Execute if the word is marked IMMEDIATE
                - Else add word at the end of the dictionnary
            ii)if interpreting:
                - Execute the word
        2. If not found
            i) Try to convert it to a number
                - add to stack if interpreting
                - add to dictionnary with (VALUE) before in the dictionnary
                    if compiling.
            ii) Print an error message "Word unknown"
    
*/

#include "parser.h"

#define     MODE_COMPILATION    1
#define     MODE_INTERPRET      0

extern char * input_buffer;
extern void * last_def;
extern void * dp0;
extern void * dp;
extern void * sp;

extern void * rp;
extern void * rp0;

char * in;

unsigned char mode = MODE_INTERPRET;

// GetNextWord()
//
// Function:    Gets next word in input buffer
// Arguments:   next_word => result buffer
// Returns:     Nothing
//
void GetNextWord( char * next_word)
{
    int i = 0;

    // Remove blanks or tabs before the word
    while( in[0] == ' ' || in[0] == '\t' )
        in += sizeof(char);

    // Store the word
    while( in[0] != ' ' && in[0] != '\t' && in[0] != 0 )
    {
        next_word[i++] = in[0];
        in += sizeof(char);
    }
    next_word[i++] = 0;
}

// tick()
//
// Function:    find a word given its name in the dictionnary
// Arguments:   word: string of the word
// Returns:     pointer containing the pfa to the word
//
void * tick(unsigned char *word)
{
    // Take the last_definition
    void * definition = last_def;
    void * pfa = 0;
    unsigned char boolean = 0;

    // While we didn't find the word and no more definition
    while( boolean == 0 && definition != 0)
    {
        void * name_ptr = definition+sizeof(unsigned char);

        // Compare the name
        if( strcmp(word, (unsigned char *) name_ptr) == 0 )
        {
            pfa = definition;
            boolean = 1;
        }
        else    // If different, go to previous definition
            memcpy( &definition, name_ptr+strlen((unsigned char *) name_ptr)+1, sizeof(void *) );
    }        
    
    return (void *) pfa;
}

// pfa2cfa()
//
// Function:    convert a pfa to a cfa
// Arguments:   pfa of the word
// Returns:     pointer containing the cfa of the word
//
void * pfa2cfa(void * pfa)
{
   void * cfa;
   unsigned char length;

   if( pfa == 0) return 0;

   // Skip length byte
   cfa = pfa + sizeof(unsigned char);
   
   // Skip name
   memcpy(&length,pfa,sizeof(unsigned char));
   length = length & 31;

   cfa += (length+1)*sizeof(char);

   // Skips previous pfa
   cfa += sizeof(void *);   
    
   return cfa;
}

// is_numeric()
//
// Function:    Test if a string is numerical
// Arguments:   string
// Returns:     0 if numerical, else 1.
//
char is_numeric(unsigned char * str)
{
    unsigned char * temp = str;
    while(temp[0] != 0 )
    {
       if( temp[0] < '0' || temp[0] > '9' )
            return 1;
       
       temp++;
    }
    return 0;
}


// parser()
//
// Function:    See top of the file
// Arguments:   None
// Return:      Nothing
// 
void parser()
{
   // To store the next word
   char next_word[32];

   void * cfa;
   int length = strlen(input_buffer);
   
   // Makes in the beggining of input_buffer
   in = input_buffer;

   // Continues until the input_buffer gets empty   
   while( in != input_buffer+length * sizeof(char) )
   {
      GetNextWord(next_word);

      // If word is not empty...
      if( next_word[0] != 0 )
      {
         // Tick find the pfa of the word
         unsigned char firstbyte = 0;
         void * temp_pfa = tick(next_word);
         

         cfa = pfa2cfa( temp_pfa );
         
         if( cfa != 0)
         {
            memcpy( &firstbyte, temp_pfa, sizeof(unsigned char) );
            // & 32 => Filter for the 3rd bit
            do_real_word(cfa, firstbyte & 32);
         }
         // Else cfa == 0
         else
         {
            // Try to convert to a numerical value
            if( is_numeric(next_word) == 0)
            {
                long number = atoi(&next_word);
               
                if ( mode == 0)  // INTERPRETATION
                { 
                    // Add the number on stack
                    memcpy(sp,&number,sizeof(long) );
                    sp += sizeof(long);
                }
                else
                {
                    // Add the CFA of value
                    void * value = (void *) 1;
                    memcpy(dp,&value,sizeof(void *) );
                    dp += sizeof(void *);

                    // Add the value 
                    memcpy(dp,&number,sizeof(long) );
                    dp += sizeof(long);
                }
            }
            else  // Word unknown
                printf("%s: Undefined word\n", next_word);
         }  // else cfa == 0

      } // If word not empty
   }    //while in...

}

// do_real_word()
//
// Function:    See top of the file
// Arguments:   cfa of the word to execute or compile
//              flags ( immediate word or not )
// Return:      Nothing
// 
void do_real_word(void * cfa, unsigned char flags)
{
    if( mode == 1) // COMPILATION
    {
        // IMMEDIATE WORD
        if( flags == 32)
            interpret(cfa);
        else
        {
            // We just add the cfa at the end of the dictionnary
            memcpy(dp, &cfa, sizeof(void *) );
            dp += sizeof(void *);
        } 
    }
    else    // INTERPRETEATION
        interpret(cfa);
}

// interpret()
//
// Function:    Execute a word given its cfa
// Arguments:   cfa
// Return:      Nothing
// 
void interpret( void * cfa )
{
    unsigned char type; 
    void (*fp)();
    void * cfa_data = cfa + sizeof(unsigned char);

    memcpy(&type, cfa, sizeof(unsigned char) );
             
    if( type == 0) // EXEC_WORD
    {
       // Retrieve exec address
       memcpy( &fp, cfa_data, sizeof(void *) );
       // Execute address
       fp();
    }
    else if (type == 1) // COLON_WORD
    {
       // Add the cfa on top of the return stack
       memcpy(rp, &cfa_data , sizeof(void *) );
       rp += sizeof(void *);

       printf("", cfa_data);
       
       // Execute the stack
       execute();
    }
    else
       printf("Corrupted memory in dictionnary.\n");
}

// execute()
//
// Function:    Execute the return stack (if forth-defined word)
// Arguments:   None
// Return:      Nothing
// 
void execute()
{
    void * cfa;
    void * ip;   

    long temp;
 
    while( rp != rp0)
    {
       // Unstack an element
       rp -= sizeof(void *);
       memcpy(rp, &cfa, sizeof(void *) );

       ip = cfa;
       // printf("%d ", cfa);

       memcpy(&temp, ip, sizeof(long) );
       while(temp != 0)
       {
          if( temp == 1)   // 1 is the CFA indicating a value
          {
              ip += sizeof(long *);
              
              // Add the value on the stack
              memcpy(sp,ip,sizeof(long) );
              sp += sizeof(long);
          }
          else
          {
            void * new_cfa;
            memcpy( &new_cfa, ip, sizeof(void *) );
          
            interpret(new_cfa);
          }

          // Go to next instruction
          ip += sizeof(long *);
          memcpy(&temp, ip, sizeof(long) );
       }  

    }

}


