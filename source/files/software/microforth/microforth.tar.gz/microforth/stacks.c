/*
    stacks.c
    Microforth interpreter

    By Eric Abouaf
    neyric@via.ecp.fr
    June 10, 2005

    Contains the init and free functions for data and return stacks.

*/

#include "stacks.h"


#define     DATASTACK_SIZE  3000
#define     RETURNSTACK_SIZE  3000


// Pointers for the return stack
void * rp0;
void * rp;

// Pointers for the data stack
void * sp0;
void * sp;

// init_stacks()
//
// Function:    Allocate space for data and return stacks
// Arguments:   None
// Return:      Nothing
//
void init_stacks()
{
    // Allocates space for data stack
    sp0 = (void *) malloc(DATASTACK_SIZE);   
    if(sp0 == 0)
    {
        printf("init_stacks: Unable to allocate space for data stack\n");
    }
    sp = sp0;
    
    // Allocates space for return stack
    rp0 = (void *) malloc(RETURNSTACK_SIZE);   
    if(rp0 == 0)
    {
        printf("init_stacks: Unable to allocate space for return stack\n");
    }
    rp = rp0;
} 

// free_stacks()
//
// Function:    Free memory allocated for the stacks
// Arguments:   None
// Return:      Nothing
//
void free_stacks()
{
   // Free stacks
   free( (void *) rp0);
   free( (void *) sp0);
}

