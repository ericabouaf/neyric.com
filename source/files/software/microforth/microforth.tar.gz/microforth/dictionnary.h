
// Contains definitions for dictionnary.c

void init_dictionnary();
void core_definitions();
void free_dictionnary();
void add_core_word(const char *word, void *function, unsigned char flags);

