
// contains definitions for input_buffer.c

void init_inputbuffer();
void free_inputbuffer();
void fill_inputbuffer();

