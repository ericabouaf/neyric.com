
// Contains declarations of core.c

void dup();
void mult();
void dpat();
void colon();
void semicolon();
void quit();
void dot();
void dots();
void plus();
void words();

