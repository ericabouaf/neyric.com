/*
    core.c
    Microforth interpreter

    By Eric Abouaf
    neyric@via.ecp.fr
    June 11, 2005

    This file contains some core word definitions.
    All the functions are meant to be added to the dictionnary
    through add_core_word()
*/


#include "core.h"

#include "parser.h"
#include "main.h"

extern void * sp;
extern void * dp;
extern void * sp0;
extern void * last_def;

extern unsigned char mode;

// dup
void dup()
{
    if(sp == sp0)
        printf("dup: error, empty stack\n");
    else
    {
        memcpy(sp, sp-sizeof(long), sizeof(long) );
        sp += sizeof(long);
    }
}

// DP@
void dpat()
{
    memcpy(sp, &dp, sizeof(void *) );
    sp += sizeof(void *); 
}

// : (immediate word)
void colon()
{
    char next_word[32];
    unsigned char length;
    unsigned char temp;

    void * temp_dp = dp;

    // Switch to compilation mode
    mode = 1;   

    // GetNextWord in input_buffer
    GetNextWord(next_word);
    length = (unsigned char) strlen(next_word);

    // write word header
    memcpy(dp, &length, sizeof(unsigned char) );
    dp += sizeof(unsigned char); 

    // write the name
    memcpy(dp, (void *) next_word, length+1);     
    dp += sizeof(char)*(length+1);

    // Write the pfa of the previous word
    memcpy(dp, &last_def, sizeof(void *));
    dp += sizeof(void *);

    // Write info about a colon word
    temp = 1;
    memcpy(dp, &temp, sizeof(unsigned char) );
    dp += sizeof(unsigned char); 

    // Update last_def
    last_def = temp_dp;
}

// ; (immediate word)
void semicolon()
{
    void * temp = 0;

    // Switch to interpretation mode
    mode = 0;   

    // Write the end of the word (0)
    memcpy(dp, &temp, sizeof(void *) );
    dp += sizeof(void *); 
}

// quit
void quit()
{
   printf("\nGoodbye !\n\n");
   free_mem();
   exit(0);
}

// .
void dot()
{
    if(sp == sp0)
        printf(".: error, empty stack\n");
    else
    {
        long temp;
        sp -= sizeof(long);
        memcpy(&temp, sp, sizeof(long) );
        printf("%d ", temp);
    }
}

// +
void plus()
{
    if(sp <= sp0+sizeof(long) )
        printf("+: error, empty stack\n");
    else
    {
        long x1, x2;
        sp -= sizeof(long);
        memcpy(&x1, sp, sizeof(long) );
        sp -= sizeof(long);
        memcpy(&x2, sp, sizeof(long) );

        x1 += x2;
        memcpy(sp, &x1, sizeof(long) );
        sp += sizeof(long);
    }
}

// *
void mult()
{
    if(sp <= sp0+sizeof(long) )
        printf("+: error, empty stack\n");
    else
    {
        long x1, x2;
        sp -= sizeof(long);
        memcpy(&x1, sp, sizeof(long) );
        sp -= sizeof(long);
        memcpy(&x2, sp, sizeof(long) );

        x1 = x1*x2;
        memcpy(sp, &x1, sizeof(long) );
        sp += sizeof(long);
    }
}

// .s
void dots()
{
    void * temp = sp0;

    printf("<%d> ", (sp-sp0)/sizeof(long));

    while( temp != sp)
    {
        long numero;
        memcpy(&numero, temp, sizeof(long) );
        printf("%d ", numero);
        temp += sizeof(long);
    }
}


// words
void words()
{
    void * definition = last_def;

    // While we didn't find no more definition
    while( definition != 0)
    {
        void * name_ptr = definition+sizeof(unsigned char);

        printf("%s ", (unsigned char *) name_ptr);

        // Previous definition address is at name_ptr+lengthof(name)
        memcpy( &definition, name_ptr+strlen((unsigned char *) name_ptr)+1, sizeof(void *) );
    }
    printf("\n");    
}


