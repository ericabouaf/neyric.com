
// Definitions for parser.c

void GetNextWord( char * next_word);
void parser();
void do_real_word(void * cfa, unsigned char flags);
void interpret( void * cfa);
void execute();

