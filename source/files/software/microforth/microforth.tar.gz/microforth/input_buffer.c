/*
    input_buffer.c
    Microforth interpreter
    
    By Eric Abouaf
    neyric@via.ecp.fr
    June 10, 2005

    This file contains the input buffer functions: init, free, and fill

*/

#include "input_buffer.h"

#define INPUTBUFFER_SIZE    256

// Input buffer pointer
char * input_buffer;

// init_inputbuffer
//
// Function:    Allocate memory for the input_buffer
// Arguments:   None
// Return:      Nothing
//
void init_inputbuffer()
{
    // Allocates space for input_buffer
    input_buffer = (char *) malloc(INPUTBUFFER_SIZE);   
    if(input_buffer == 0)
    {
        printf("init_inputbuffer: Unable to allocate space for input_buffer\n");
    }
} 

// free_inputbuffer
//
// Function:    Free memory allocated for the input_buffer
// Arguments:   None
// Return:      Nothing
//
void free_inputbuffer()
{
   // frees input_buffer
   free( (void *) input_buffer);
}

// fill_inputbuffer
//
// Function:    Fills the input_buffer with data from stdin
//              and prevent buffer overflow. (better than gets)
// Arguments:   None
// Return:      Nothing
//
void fill_inputbuffer()
{
   // Fills input_buffer
   char c = 0;
   unsigned char i = 0;

   while( c != '\n' )
   {
       // Get char from stdin
       c = getchar();

       // Prevent buffer overflow
       if( i == INPUTBUFFER_SIZE-1)
            c = '\n';

       // Add the letter to the buffer
       input_buffer[i++] = c;
   }
   input_buffer[i-1] = 0;    // i-1 cause we remove the '\n'
}

